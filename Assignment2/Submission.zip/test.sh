./printer 4 &
sleep 2
./client 1 11 14 &
sleep 2
./client 2 12 14 &
sleep 2
./client 3 13 14 &
sleep 2
./client 4 14 14 &
sleep 2
./client 5 15 14 &
sleep 2
./client 6 16 14 &
sleep 2
./client 7 17 14 &
